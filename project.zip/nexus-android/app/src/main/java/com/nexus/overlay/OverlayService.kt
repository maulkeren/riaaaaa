package com.nexus.overlay

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.nexus.overlay.STOP"
        const val ACTION_REFRESH = "com.nexus.overlay.REFRESH"
        @Volatile var running = false
        private const val CHANNEL_ID = "nexus_overlay"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var web: WebView? = null
    private var bubble: BubbleView? = null
    private lateinit var webLp: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private var interactive = true
    private var curText = "NX"
    private var curColor = 0xFFA855F7.toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH) {
            bubble?.update(curText, curColor, loadPhoto())
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (web == null) setupOverlay()
        running = true
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Nexus Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Nexus aktif")
            .setContentText("Overlay berjalan. Ketuk untuk buka app.")
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notif, type)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun flagsFor(interactive: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (!interactive) {
            f = f or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return f
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setupOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? = request?.url?.let { loader.shouldInterceptRequest(it) }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                showDialog(message ?: "", result, false)
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                showDialog(message ?: "", result, true)
                return true
            }
        }
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        webLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flagsFor(true),
            PixelFormat.TRANSLUCENT
        ).apply {
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(w, webLp)
        web = w

        // Bubble ">_" yang bisa digeser; ketuk = buka/tutup menu
        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(180)
        }
        val b = BubbleView(this)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (abs(dx) + abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = ox + dx
                            lp.y = oy + dy
                            wm.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        web?.evaluateJavascript("window.__nativeToggle && window.__nativeToggle()", null)
                    }
                }
                return true
            }
        })
        b.update(curText, curColor, loadPhoto())
        wm.addView(b, lp)
        bubble = b
    }

    private fun showDialog(msg: String, r: JsResult, alertOnly: Boolean) {
        val builder = AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
            .setMessage(msg)
            .setPositiveButton("OK") { _, _ -> r.confirm() }
            .setOnCancelListener { r.cancel() }
        if (!alertOnly) builder.setNegativeButton("Batal") { _, _ -> r.cancel() }
        val d = builder.create()
        d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        d.show()
    }

    private fun applyInteractive(v: Boolean) {
        if (v == interactive) return
        interactive = v
        webLp.flags = flagsFor(v)
        try {
            web?.let { wm.updateViewLayout(it, webLp) }
        } catch (_: Exception) {
        }
    }

    private fun loadPhoto(): Bitmap? {
        val f = File(filesDir, "bubble.png")
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    inner class Bridge {
        @JavascriptInterface
        fun setBubble(text: String, color: String) {
            main.post {
                curText = if (text.isBlank()) "NX" else text.take(3)
                curColor = try { Color.parseColor(color) } catch (_: Exception) { curColor }
                bubble?.update(curText, curColor, loadPhoto())
            }
        }

        @JavascriptInterface
        fun stopOverlay() {
            main.post { stopSelf() }
        }

        @JavascriptInterface
        fun setInteractive(v: Boolean) {
            main.post { applyInteractive(v) }
        }
    }

    override fun onDestroy() {
        running = false
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { web?.let { wm.removeView(it); it.destroy() } } catch (_: Exception) {}
        bubble = null
        web = null
        super.onDestroy()
    }
}
