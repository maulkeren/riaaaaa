package com.nexus.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val pickReq = 7

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF07060B.toInt())
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "NEXUS CLIENT"
            textSize = 28f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(0xFFA855F7.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        }
        val start = Button(this).apply {
            text = "MULAI OVERLAY"
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "STOP OVERLAY"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "Overlay dihentikan", Toast.LENGTH_SHORT).show()
            }
        }
        val photo = Button(this).apply {
            text = "FOTO IKON NX"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(Intent.createChooser(i, "Pilih foto"), pickReq)
            }
        }
        val clear = Button(this).apply {
            text = "HAPUS FOTO IKON"
            setOnClickListener {
                File(filesDir, "bubble.png").delete()
                refreshOverlay()
                Toast.makeText(this@MainActivity, "Foto ikon dihapus", Toast.LENGTH_SHORT).show()
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(photo)
        root.addView(clear)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this))
            "Izin overlay aktif.\nTekan MULAI OVERLAY, lalu buka aplikasi lain."
        else
            "Butuh izin \"Tampilkan di atas aplikasi lain\".\nTekan MULAI OVERLAY untuk mengaktifkan."
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Aktifkan izin, lalu kembali ke app ini", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    private fun refreshOverlay() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickReq || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            savePhoto(uri)
            refreshOverlay()
            Toast.makeText(this, "Foto ikon disimpan", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
        }
    }

    /** Potong persegi dari tengah, kecilkan, simpan sebagai bubble.png. */
    private fun savePhoto(uri: Uri) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("decode gagal")
        val m = minOf(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - m) / 2, (bmp.height - m) / 2, m, m)
        val out = Bitmap.createScaledBitmap(square, 192, 192, true)
        FileOutputStream(File(filesDir, "bubble.png")).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
