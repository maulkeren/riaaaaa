package com.nexus.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

/** Bubble NX: lingkaran berwarna + teks, atau foto kustom (dipotong bulat). */
class BubbleView(context: Context) : View(context) {

    private var label = "NX"
    private var color = 0xFFA855F7.toInt()
    private var photo: Bitmap? = null

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF10091A.toInt()
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    fun update(newLabel: String, newColor: Int, newPhoto: Bitmap?) {
        label = newLabel
        color = newColor
        photo = newPhoto
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = width.toFloat()
        ring.strokeWidth = s * 0.05f
        val r = s / 2 - ring.strokeWidth
        val p = photo
        if (p != null) {
            val shader = BitmapShader(p, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = Matrix()
            m.setScale(s / p.width, s / p.height)
            shader.setLocalMatrix(m)
            photoPaint.shader = shader
            canvas.drawCircle(s / 2, s / 2, r, photoPaint)
        } else {
            bg.color = color
            canvas.drawCircle(s / 2, s / 2, r, bg)
            text.textSize = s * 0.36f
            val fm = text.fontMetrics
            val y = s / 2 - (fm.ascent + fm.descent) / 2
            canvas.drawText(label, s / 2, y, text)
        }
        canvas.drawCircle(s / 2, s / 2, r, ring)
    }
}
